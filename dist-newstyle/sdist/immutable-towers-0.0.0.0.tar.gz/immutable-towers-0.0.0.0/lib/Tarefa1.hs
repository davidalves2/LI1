{-|
Module      : Tarefa1
Description : Invariantes do Jogo
Copyright   : José Manuel Peixoto Rocha <a106887@alunos.uminho.pt>
              David Jose Barbosa Alves <a107324@alunos.uminho.pt>


Módulo para a realização da Tarefa 1 de LI1 em 2024/25.
-}
module Tarefa1 where

import LI12425

validaJogo :: Jogo -> Bool
validaJogo = undefined
