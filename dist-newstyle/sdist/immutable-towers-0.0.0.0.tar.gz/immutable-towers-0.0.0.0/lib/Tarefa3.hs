{-|
Module      : Tarefa3
Description : Mecânica do Jogo
Copyright   : José Manuel Peixoto Rocha <a106887@alunos.uminho.pt>
              David Jose Barbosa Alves <a107324@alunos.uminho.pt>


Módulo para a realização da Tarefa 3 de LI1 em 2024/25.
-}
module Tarefa3 where

import LI12425

atualizaJogo :: Tempo -> Jogo -> Jogo
atualizaJogo = undefined
